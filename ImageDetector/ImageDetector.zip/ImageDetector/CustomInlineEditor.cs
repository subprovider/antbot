﻿
//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------

using System.Activities.Presentation.PropertyEditing;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace ktds.UBot.Activities.ImageDetector
{
    class CustomInlineEditor : PropertyValueEditor
    {

        public CustomInlineEditor()
        {
            this.InlineEditorTemplate = new DataTemplate();

            FrameworkElementFactory gridFactory = new FrameworkElementFactory(typeof(Grid));

            var column1 = new FrameworkElementFactory(typeof(ColumnDefinition));
            column1.SetValue(ColumnDefinition.WidthProperty, new GridLength(1, GridUnitType.Star));

            /*
            var column2 = new FrameworkElementFactory(typeof(ColumnDefinition));
            column2.SetValue(ColumnDefinition.WidthProperty, new GridLength(1, GridUnitType.Auto));
            */

            gridFactory.AppendChild(column1);
            //gridFactory.AppendChild(column2);


            FrameworkElementFactory textBox = new FrameworkElementFactory(typeof(TextBox));
            Binding textBinding = new Binding("StringValue");
            textBox.SetValue(TextBox.TextProperty, textBinding);
            textBox.SetValue(Grid.ColumnProperty, 0);
            gridFactory.AppendChild(textBox);

            /*
            FrameworkElementFactory slider = new FrameworkElementFactory(typeof(Slider));
            Binding sliderBinding = new Binding("Value");
            sliderBinding.Mode = BindingMode.TwoWay;
            slider.SetValue(Slider.MinimumProperty, 0);
            slider.SetValue(Slider.MaximumProperty, 100);
            slider.SetValue(Slider.ValueProperty, sliderBinding);
            slider.SetValue(Grid.ColumnProperty, 1);
            gridFactory.AppendChild(slider);
            */

            this.InlineEditorTemplate.VisualTree = gridFactory;

        }
    }
}
