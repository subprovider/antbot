﻿using System;
using System.Activities.Presentation.Metadata;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ktds.UBot.Activities.ImageDetector
{
    // ImageDetectorActivityDesign.xaml에 대한 상호 작용 논리
    public partial class ImageDetectorActivityDesign
    {
        private Point _point;
        private HitType _mouseHitType = HitType.None;
        // True if a drag is in progress.
        private bool _dragInProgress = false;

        // The drag's last point.
        private Point _lastPoint;

        public Point RectPoint
        {
            get { return this._point; }
            private set
            {
                this._point = value;
                this.OnPropertyChanged("RectPoint");
            }
        }

        public double AreaWidth { get; private set; }
        public double AreaHeight { get; private set; }


        public ImageDetectorActivityDesign()
        {
            InitializeComponent();

            
        }


        public static void RegisterMetadata(AttributeTableBuilder builder)
        {
            builder.AddCustomAttributes(typeof(ImageDetectorActivity), new DesignerAttribute(typeof(ImageDetectorActivityDesign)));
            builder.AddCustomAttributes(typeof(ImageDetectorActivity), new DescriptionAttribute("ktds ubot's ImageDetectorActivity"));
        }

        private List<IntPtr> _results = new List<IntPtr>();
        [DllImport("user32.Dll")]
        private static extern int EnumWindows(EnumWindowsProc x, int y);
        [DllImport("user32.dll")]
        public static extern int GetWindowThreadProcessId(IntPtr handle, out int processId);
        private delegate int EnumWindowsProc(IntPtr hwnd, int lParam);
        private IntPtr[] GetWindowHandlesForThread(int threadHandle)
        {
            _results.Clear();
            EnumWindows(WindowEnum, threadHandle);
            return _results.ToArray();
        }

        private int WindowEnum(IntPtr hWnd, int lParam)
        {
            int processID = 0;
            int threadID = GetWindowThreadProcessId(hWnd, out processID);
            if (threadID == lParam) _results.Add(hWnd);
            return 1;
        }
        public void btnCaptureClick(object sender, RoutedEventArgs e)
        {
            FormCapture formCapture = new FormCapture();
            formCapture.ShowDialog();

            if(!formCapture.Captured)
               return;

            
            Image img = (Image)(sender as Button).FindName("targetImage");

            img.Source = new BitmapImage(new Uri(formCapture.CaptureImageFileName, UriKind.Relative));
           
            //MessageBox.Show("clicked");
            
            return;

            MessageBox.Show(AppDomain.GetCurrentThreadId().ToString());

            IntPtr[] windows = GetWindowHandlesForThread(AppDomain.GetCurrentThreadId());
            if (windows != null && windows.Length > 0)
                foreach (IntPtr hWnd in windows)
                    MessageBox.Show("\t\twindow {0:x}", hWnd.ToString());

            /*
            foreach (Process procesInfo in Process.GetProcesses())
            {
                Console.WriteLine("process {0} {1:x}", procesInfo.ProcessName, procesInfo.Id);
                foreach (ProcessThread threadInfo in procesInfo.Threads)
                {
                    Console.WriteLine("\tthread {0:x}", threadInfo.Id);
                    IntPtr[] windows = GetWindowHandlesForThread(threadInfo.Id);
                    if (windows != null && windows.Length > 0)
                        foreach (IntPtr hWnd in windows)
                            Console.WriteLine("\t\twindow {0:x}", hWnd.ToInt32());
                }
            }
            */
        }

        public void CanvasMouseEnter(object sender, MouseEventArgs e)
        {
            Cursor = Cursors.Hand;
        }

        public void CanvasMouseLeave(object sender, MouseEventArgs e)
        {
            Cursor = Cursors.Arrow;
        }

        private enum HitType
        {
            None, Body, UL, UR, LR, LL, L, R, T, B
        };

        private HitType SetHitType(Point point, double left, double top, double right, double bottom)
        {
           if (point.X < left) return HitType.None;
           if (point.X > right) return HitType.None;
           if (point.Y < top) return HitType.None;
           if (point.Y > bottom) return HitType.None;

           return HitType.Body;
        }

        private void SetMouseCursor()
        {
            // See what cursor we should display.
            Cursor desired_cursor = Cursors.Arrow;
            switch (_mouseHitType)
            {
                case HitType.Body:
                    desired_cursor = Cursors.Hand; 
                    break;
                default:
                    desired_cursor = Cursors.Arrow;
                    break;
            }

            // Display the desired cursor.
            if (Cursor != desired_cursor) Cursor = desired_cursor;
        }

        private void canvas1_MouseDown(object sender, MouseButtonEventArgs e)
        {

            Border rect = (Border)(sender as Canvas).FindName("RecodBorderSizeObject");

            double left = Canvas.GetLeft(rect);
            double top = Canvas.GetTop(rect);
            double right = left + rect.Width;
            double bottom = top + rect.Height;

            
            _mouseHitType = SetHitType(Mouse.GetPosition(sender as Canvas), left, top, right, bottom);

            
            SetMouseCursor();
            if (_mouseHitType == HitType.None) return;

            _lastPoint = Mouse.GetPosition((sender as Canvas));
            _dragInProgress = true;
        }

        private void canvas1_MouseMove(object sender, MouseEventArgs e)
        {
            Border rect = (Border)(sender as Canvas).FindName("RecodBorderSizeObject");

            if (!_dragInProgress)
            {
                double left = Canvas.GetLeft(rect);
                double top = Canvas.GetTop(rect);
                double right = left + rect.Width;
                double bottom = top + rect.Height;

                _mouseHitType = SetHitType(Mouse.GetPosition((sender as Canvas)), left, top, right, bottom);
                SetMouseCursor();
            }
            else
            {

                // See how much the mouse has moved.
                Point point = Mouse.GetPosition((sender as Canvas));
                double offsetX = point.X - _lastPoint.X;
                double offsetY = point.Y - _lastPoint.Y;

                // Get the rectangle's current position.
                double newX = Canvas.GetLeft(rect);
                double newY = Canvas.GetTop(rect);
                //double newWidth = rect.Width;
                //double newHeight = rect.Height;

                if (newX <= 0)
                {
                    newX = 0;
                }

                if (newY <= 0)
                {
                    newY = 0;
                }

           

                // Update the rectangle.
                switch (_mouseHitType)
                {
                    case HitType.Body:
                        newX += offsetX;
                        newY += offsetY;
                        break;
                }

                // Don't use negative width or height.
                //if ((newWidth > 250) && (newHeight > 250))
                //{
                    // Update the rectangle.
                    Canvas.SetLeft(rect, newX);
                    Canvas.SetTop(rect, newY);
                    //rect.Width = newWidth;
                    //rect.Height = newHeight;

                    this.RectPoint = new Point(newX, newY);
                    //this.AreaWidth = newWidth;
                    //this.AreaHeight = newHeight;

                    // Save the mouse's new location.
                    _lastPoint = point;
                //}
            }
        }

        // Stop dragging.
        private void canvas1_MouseUp(object sender, MouseButtonEventArgs e)
        {
            _dragInProgress = false;
        }

        #region Inotify
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion

    }
}
