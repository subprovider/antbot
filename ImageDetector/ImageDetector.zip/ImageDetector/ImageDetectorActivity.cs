﻿
//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------


using Emgu.CV;
using Emgu.CV.Structure;
using System;
using System.Activities;
using System.Activities.Presentation.Metadata;
using System.Activities.Presentation.PropertyEditing;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace ktds.UBot.Activities.ImageDetector
{

    [Designer(typeof(ImageDetectorActivityDesign))]
    public sealed class ImageDetectorActivity : CodeActivity
    {
        private int m_capacity = 95;
        private int m_retry = 1;

        [RequiredArgument]
        [Category("Image Detect Option")]
        public string ImageFileName { get; set; }
        public int Capacity { get { return m_capacity; } set { m_capacity = value; } }
        public int Retry { get { return m_retry; } set { m_retry = value; } }

        [DefaultValue(null)]

        [Category("Execution Option")]
        public Point ClickPosition { get; set; }
        public EventType ActionType { get; set; }
        public InArgument<string> Text { get; set; }

        [Category("Output")]
        private Rectangle detectPosition;
        public OutArgument<Rectangle> DetectPosition { get; set; }

        public ImageDetectorActivity()
        {
            ClickPosition = new Point(0, 0);
            detectPosition = new Rectangle(0, 0, 0, 0);

            AttributeTableBuilder builder = new AttributeTableBuilder();
            builder.AddCustomAttributes(typeof(ImageDetectorActivity), "Capacity", new EditorAttribute(typeof(CustomInlineEditor), typeof(PropertyValueEditor)));
            builder.AddCustomAttributes(typeof(ImageDetectorActivity), "ImageFileName", new EditorAttribute(typeof(FilePickerEditor), typeof(DialogPropertyValueEditor)));
            builder.AddCustomAttributes(typeof(ImageDetectorActivity), "Retry", new EditorAttribute(typeof(CustomInlineEditor), typeof(PropertyValueEditor)));
            MetadataStore.AddAttributeTable(builder.CreateTable());
        }


        private Bitmap CaptureScreen()
        {
            //Create a new bitmap.
            var bmpScreenshot = new Bitmap(Screen.PrimaryScreen.Bounds.Width,
                                           Screen.PrimaryScreen.Bounds.Height);
            //PixelFormat.Format32bppArgb);

            // Create a graphics object from the bitmap.
            var gfxScreenshot = Graphics.FromImage(bmpScreenshot);

            // Take the screenshot from the upper left corner to the right bottom corner.
            gfxScreenshot.CopyFromScreen(Screen.PrimaryScreen.Bounds.X,
                                        Screen.PrimaryScreen.Bounds.Y,
                                        0,
                                        0,
                                        Screen.PrimaryScreen.Bounds.Size,
                                        CopyPixelOperation.SourceCopy);

            // Save the screenshot to the specified path that the user has chosen.
            // bmpScreenshot.Save("Screenshot.png", ImageFormat.Png);

            return bmpScreenshot;
        }

        protected override void Execute(CodeActivityContext context)
        {
            //MessageBox.Show("start");

            detectPosition.X = 0;
            detectPosition.Y = 0;
            detectPosition.Width = 0;
            detectPosition.Height = 0;

            this.DetectPosition.Set(context, detectPosition);

            Mat mat = CvInvoke.Imread(ImageFileName, Emgu.CV.CvEnum.ImreadModes.AnyColor);

            Image<Bgr, byte> source = new Image<Bgr, byte>(CaptureScreen());
            Image<Bgr, byte> template = mat.ToImage<Bgr, Byte>();

            int nRetry = 0;
            do
            {
                using (Image<Gray, float> result = source.MatchTemplate(template, Emgu.CV.CvEnum.TemplateMatchingType.CcoeffNormed))
                {
                    double[] minValues, maxValues;
                    Point[] minLocations, maxLocations;
                    result.MinMax(out minValues, out maxValues, out minLocations, out maxLocations);

                    // You can try different values of the threshold. I guess somewhere between 0.75 and 0.95 would be good.
                    if (maxValues[0] > (double)Capacity / 100) //0.9
                    {
                        // This is a match. Do something with it, for example draw a rectangle around it.
                        detectPosition = new Rectangle(maxLocations[0], template.Size);

                        //imageToShow.Draw(match, new Bgr(Color.Red), 3);

                        Debug.WriteLine(detectPosition.ToString());
                        MessageBox.Show(detectPosition.ToString());

                        //MoveCursor(x, y);

                        this.DetectPosition.Set(context, detectPosition);
                        break;
                    }
                }

                nRetry++;
                Thread.Sleep(1000);
                MessageBox.Show(nRetry.ToString());
            } while (nRetry < Retry);
            // Obtain the runtime value of the Text input argument
            string text = context.GetValue(this.Text);
            
                Console.WriteLine("Value entered was {0}", text);
            Console.WriteLine("Image file name is {0}", ImageFileName);
             
        }
    }

    public enum EventType
    {
        None = 0,
        LButtonClick,
        LButtonDoubleClick,
        KeyIn
    }

}
